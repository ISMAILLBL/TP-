Java Maven

This repository was created by Ismail Boulaich as part of the
Build a Java application with Maven

tutorial available in the Jenkins User Documentation
.

The project contains a simple Java application that prints the message
"Hello World!" to the console. It also includes unit tests that verify the correct
behavior of the main application. Test execution results are automatically generated
and stored in JUnit XML report format.

The jenkins directory provides an example Jenkinsfile, which defines a Jenkins
Pipeline used to automate the build, test, and delivery processes. Additionally,
the jenkins/scripts subdirectory contains shell scripts executed by Jenkins during
the "Deliver" stage of the Pipeline.